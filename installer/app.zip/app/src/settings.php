<?php
return [
    'settings' => [
        'displayErrorDetails' => true, // set to false in production
        // db settings
        'db' => [
            'hostname' => "DBHOSTNAME",
            'username' => "DBUSERNAME",
            'password' => "DBPASSWORD",
            'dbname'   => "DBDATABASENAME"
        ],

        'hmvc' => [
            'modulePath' => APPPATH . 'modules'.DIRECTORY_SEPARATOR,
        ],
    ],
];