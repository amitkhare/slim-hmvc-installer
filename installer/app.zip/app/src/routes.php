<?php
// Routes
//$app->get('/someroute', function ($request, $response, $args) {
    // Sample log message
//});
