<html>
<head>
  <title><?php echo $title; ?></title>
</head>
<body>
<?php echo $title." :generated: ".$name; ?>
</body>
</html>