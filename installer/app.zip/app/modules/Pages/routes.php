<?php
$app->get('/', '\Pages:home');