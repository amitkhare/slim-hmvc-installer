<?php
$app->get('/', '\Pages:home');
$app->get('/pages/users', '\Pages:users');